module {
  func.func @inference_to_compile(%arg0: tensor<1x81x!FHE.esint<15>>) -> tensor<1x4x!FHE.esint<15>> {
    %cst = arith.constant dense<"0xFBFBFBFBFBFBFBFBFBFBFBFBFBFBFBFBFBFBFBFBFBFAFBFBFCFAFCFBFCFAFCFBFBFAFCFBFBFBFAFBFBFCFAFBFAFDFAFBDA051CFBF122E7FB0DE9FEFBFBFBFBFBFCFAFBFBFBFAFBFB12D616FB1FD00BFB12C020FBFBFBFBFBFBFBFBFBFBFBFBFBFBFBFBFBFBFBFBFBFBFBFBFBFBFBFBFBFBFBFBFBFBFBFBFBFBFBFBFBFBFBFBFBFBFBFBFBFBFBFBFBFBFAFBFBFBFBFBFBFBFBFBFBFBFBFBFBFBFBFBFBFCF8FDFBFAE304FBEB07FCFBFBFBFBFBFBFBFBFBFBFBFBFBFEE909FB09D70DFBF0FD03FBFBFBFBFBFBFBFBFBFBFBFBFBFBFBFBFBFBFBFBFBFBFBFBFBF9FFF8FBFBFBFBFBFAFBFBFBFBFBFBFBFCFBFBFBFCFAFCFBFAFEF9FBFDF9FBFBFAFAFCFBF900F7FBFAFBFBFBF9FEFAFBFCF4EDFAFEFAFBF9FCF9FDFCFCFAFCFBFDFAFBFBFCFAFCFB143FD3FBD70209FBEC10E2FBFBFBFBFBFCFBFBFBFCFAFBFBFBFBFBFBFBFBFBFBFBFBFBFB"> : tensor<81x4xi8>
    %0 = "FHELinalg.to_unsigned"(%arg0) : (tensor<1x81x!FHE.esint<15>>) -> tensor<1x81x!FHE.eint<15>>
    %1 = "FHELinalg.matmul_eint_int"(%0, %cst) : (tensor<1x81x!FHE.eint<15>>, tensor<81x4xi8>) -> tensor<1x4x!FHE.eint<15>>
    %2 = "FHELinalg.sum"(%arg0) {axes = [1], keep_dims = true} : (tensor<1x81x!FHE.esint<15>>) -> tensor<1x1x!FHE.esint<15>>
    %c-5_i5 = arith.constant -5 : i5
    %from_elements = tensor.from_elements %c-5_i5 : tensor<1xi5>
    %3 = "FHELinalg.to_unsigned"(%2) : (tensor<1x1x!FHE.esint<15>>) -> tensor<1x1x!FHE.eint<15>>
    %4 = "FHELinalg.mul_eint_int"(%3, %from_elements) : (tensor<1x1x!FHE.eint<15>>, tensor<1xi5>) -> tensor<1x1x!FHE.eint<15>>
    %5 = "FHELinalg.to_signed"(%1) : (tensor<1x4x!FHE.eint<15>>) -> tensor<1x4x!FHE.esint<15>>
    %6 = "FHELinalg.to_signed"(%4) : (tensor<1x1x!FHE.eint<15>>) -> tensor<1x1x!FHE.esint<15>>
    %7 = "FHELinalg.sub_eint"(%5, %6) : (tensor<1x4x!FHE.esint<15>>, tensor<1x1x!FHE.esint<15>>) -> tensor<1x4x!FHE.esint<15>>
    %cst_0 = arith.constant dense<[[-1792, 5504, -5056, 128]]> : tensor<1x4xi15>
    %8 = "FHELinalg.add_eint_int"(%7, %cst_0) : (tensor<1x4x!FHE.esint<15>>, tensor<1x4xi15>) -> tensor<1x4x!FHE.esint<15>>
    return %8 : tensor<1x4x!FHE.esint<15>>
  }
}